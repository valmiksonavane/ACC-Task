package org.o7planning.sbformvalidation.model;
 
public class Gender {
 
    public static final String MALE = "M";
    public static final String FEMALE = "F";
}